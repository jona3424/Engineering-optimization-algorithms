import matplotlib.pyplot as plt

# Read the results into a DataFrame
a = [0] * 1000000

for i in range(0, 20):
    b = []
    j = 0
    with open(f"file putanja greske{i}.txt", "r") as file:
        for line in file:
            t = int(line)
            b.append(t)
            a[j] += t
            j += 1

        plt.loglog(b)
for r in range(len(a)):
    a[r] /= 20


plt.legend()
plt.title("Energy Distribution for 20 Files")
plt.show()


plt.loglog(a, color='green', linestyle='dashed', linewidth=2, markersize=8)
plt.title("Average Energy Over 20 Files")
plt.show()
