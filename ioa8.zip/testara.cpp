#include <iostream>
#include <cstdlib>
#include<random>
#include <ctime>
#include <algorithm> 
#include <limits>    
#include <fstream>
#include <string>
std::ofstream file;

const int POPULATION_SIZE = 20000;
const int MAX_ITERATIONS = 50;

const int D = 64;
int S[D] = { 173669, 275487, 1197613, 1549805, 502334, 217684, 1796841, 274708,
            631252, 148665, 150254, 4784408, 344759, 440109, 4198037, 329673, 28602,
            144173, 1461469, 187895, 369313, 959307, 1482335, 2772513, 1313997, 254845,
            486167, 2667146, 264004, 297223, 94694, 1757457, 576203, 8577828, 498382,
            8478177, 123575, 4062389, 3001419, 196884, 617991, 421056, 3017627, 131936,
            1152730, 2676649, 656678, 4519834, 201919, 56080, 2142553, 326263, 8172117,
            2304253, 4761871, 205387, 6148422, 414559, 2893305, 2158562, 465972, 304078,
            1841018, 1915571 };

int calculateFitness(int* solution) {
    int F1 = (1 << 25);
    int F2 = (1 << 25);

    for (int k = 0; k < D; k++) {
        if (solution[k] == 1) {
            F1 -= S[k];
        }
        else if (solution[k] == 2) {
            F2 -= S[k];
        }
    }

    if (F1 < 0 || F2 < 0) {
        return (1 << 26);
    }

    return (F1 + F2);
}

void crossover(const int* parent1, const int* parent2, int* child1, int* child2) {
    int crossoverPoint = std::rand() % D;
    std::copy(parent1, parent1 + crossoverPoint, child1);
    std::copy(parent2 + crossoverPoint, parent2 + D, child1 + crossoverPoint);
    std::copy(parent2, parent2 + crossoverPoint, child2);
    std::copy(parent1 + crossoverPoint, parent1 + D, child2 + crossoverPoint);
}

void mutate(int* solution) {
    int mutationPoint = std::rand() % D;
    solution[mutationPoint] = std::rand() % 3;
}

void geneticAlgorithm() {
    std::srand(static_cast<unsigned int>(std::time(nullptr)));
    std::random_device rd;
    std::mt19937 gen(rd());

    int** population = new int* [POPULATION_SIZE];
    for (int i = 0; i < POPULATION_SIZE; i++) {
        population[i] = new int[D];
        for (int j = 0; j < D; j++) {
            population[i][j] = std::rand() % 3;
        }
    }

    int bestSolution[D];
    int bestFitness = std::numeric_limits<int>::max();

    int** newParents = new int* [POPULATION_SIZE];
    for (int i = 0; i < POPULATION_SIZE; i++) {
        newParents[i] = new int[D];
    }

    for (int iteration = 0; iteration < MAX_ITERATIONS; iteration++) {
        for (int i = 0; i < POPULATION_SIZE; i++) {
            int currFitness = calculateFitness(population[i]);
            if (currFitness < bestFitness) {
                bestFitness = currFitness;
                std::copy(population[i], population[i] + D, std::begin(bestSolution));
            }

            file << bestFitness << std::endl;

        }

        std::partial_sort_copy(population, population + POPULATION_SIZE, newParents, newParents + 1000,
            [](int* a, int* b) { return calculateFitness(a) < calculateFitness(b); }
        );

        for (int i = 0; i < POPULATION_SIZE / 2; i += 2) {
            int parent1 = std::rand() % 1000;
            int parent2 = std::rand() % 1000;

            crossover(newParents[parent1], newParents[parent2], population[i], population[i + 1]);

            std::uniform_real_distribution<double> dis(0.0, 1.0);
            if (dis(gen) < 0.1)
                mutate(population[i]);
            if (dis(gen) < 0.1)
                mutate(population[i + 1]);
        }

        if (bestFitness <= 1500)
            break;
    }

    std::cout << "Solution: ";
    for (int i = 0; i < D; i++) {
        std::cout << bestSolution[i] << " ";
    }
    std::cout << std::endl;
    std::cout << "Best Fitness: " << bestFitness << std::endl;

    for (int i = 0; i < POPULATION_SIZE; i++) {
        delete[] population[i];
    }
    delete[] population;
    delete[] newParents;
}

int main() {
    for (int i = 0; i < 20; i++) {
        file.open(std::string("greske") + std::to_string(i) + ".txt");

        geneticAlgorithm();
        file.close();

    }
   

    return 0;
}