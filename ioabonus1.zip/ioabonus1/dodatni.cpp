#include <iostream>
#include <vector>

using namespace std;

const int MIN_CHECK_INDEX = 15;

bool isSequenceValid(const vector<int>& sequence, int index);
void buildSequence(vector<int>& sequence, int index);


int main() {
    vector<int> sequence(72, 0);
    buildSequence(sequence, 0);
    return 0;
}


bool isSequenceValid(const vector<int>& sequence, int index) {
    int rightSum = 0, leftSum = 0, i = index;
    while (i < index + 8) {
        leftSum += sequence[i++];
    }
    while (i < index + 16) {
        rightSum += sequence[i++];
    }
    return leftSum < rightSum;
}

void buildSequence(vector<int>& sequence, int index) {
    if (index == 72) {
        int i = 0;
        for (auto bit : sequence) {
            cout << bit;
            if (++i % 8 == 0) cout << "\n";
        }
        cout << "\n";
        return;
    }

    for (int bit : {0, 1}) {
        sequence[index] = bit;
        int checkIndex = max(0, MIN_CHECK_INDEX * ((index / MIN_CHECK_INDEX) - 1)) + index % MIN_CHECK_INDEX;
        if (index < MIN_CHECK_INDEX || isSequenceValid(sequence, checkIndex)) {
            buildSequence(sequence, index + 1);
        }
    }
}
