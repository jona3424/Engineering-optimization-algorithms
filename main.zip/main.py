import matplotlib.pyplot as plt

# Read the results into a DataFrame
prosjeci=[0]*1000000
for i in range (0,20):
    energy=[]
    j=0
#zamijeniti direktorijum da gadja dje su generisani fajlovi sa greskama
    with open("C:\\Users\\petri\\source\\repos\\Project3\\Project3\\greske"+str(i)+".txt","r") as file:
        for line in file:
            t=int(line)
            energy.append(t)
            prosjeci[j]+=t
            j+=1

    plt.loglog(energy)


plt.xlabel("Iteracije")
plt.ylabel("Energy")
plt.show()

for r in range(len(prosjeci)):
    prosjeci[r]/=20

plt.loglog(prosjeci)
plt.show()