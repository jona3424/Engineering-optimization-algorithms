#include <iostream>
#include <vector>
#include <random>
#include <cmath>
#include <fstream>
#include <string>
std::ofstream energyFile;


// Define constants based on problem requirements
const int MEMORY_SIZE = 32 * 1024 * 1024; // 32 MiB in bytes
const int MAX_ITERATIONS = 100000;
const double INITIAL_TEMP = 64.0;
const double COOLING_RATE = 0.95;
const int NUM_FILES = 64; // Assuming there are 64 files as per your problem statement

// Function prototypes
std::vector<int> generateNeighbor(const std::vector<int>&, std::mt19937&,int h);
int calculateEnergy(const std::vector<int>&, const std::vector<int>&);

// Main simulated annealing function
std::vector<int> simulatedAnnealing(const std::vector<int>& fileSizes) {
    std::random_device rd;
    std::mt19937 gen(rd());
    std::uniform_real_distribution<> dis(0, 1);

    // Initialize state
    std::vector<int> bestState(NUM_FILES, 0);
    int bestEnergy = calculateEnergy(bestState, fileSizes);


    for(int ij=0;ij<10;ij++){
        double temp = INITIAL_TEMP;
        std::vector<int> currentState = bestState;

        
        for (int i = 0; i < MAX_ITERATIONS; ++i) {
            int HAMING = (double(1 - 20) * i) / (MAX_ITERATIONS - 1) + 20;
            std::vector<int> newState = generateNeighbor(currentState, gen,HAMING);
            int currentEnergy = calculateEnergy(currentState, fileSizes);
            int newEnergy = calculateEnergy(newState, fileSizes);

            // Decide if we should accept the new state
            if (newEnergy < bestEnergy || dis(gen) < std::exp((currentEnergy - newEnergy) / temp)) {
                currentState = newState;
                currentEnergy = newEnergy;

                if (newEnergy < bestEnergy) {
                    bestState = newState;
                    bestEnergy = newEnergy;
                }
            }
            energyFile << bestEnergy << std::endl;
            // Cool down
            temp *= COOLING_RATE;
        }
    }
    return bestState;
}

// Define the optimization function (energy function)
int calculateEnergy(const std::vector<int>& state, const std::vector<int>& fileSizes) {
    int memory1 = MEMORY_SIZE, memory2 = MEMORY_SIZE;
    for (int i = 0; i < state.size(); ++i) {
        if (state[i] == 1) memory1 -= fileSizes[i];
        else if (state[i] == 2) memory2 -= fileSizes[i];
    }
    if (memory1 < 0 || memory2 < 0)return 2 * MEMORY_SIZE;
    return memory1 + memory2; // The energy function can be adjusted as needed
}

// Function to generate a neighboring state
std::vector<int> generateNeighbor(const std::vector<int>& state, std::mt19937& gen,int h) {

    std::vector<int> newState(state);
    std::uniform_int_distribution<> dis(0, state.size() - 1);
    std::uniform_int_distribution<> det(0, 2);
    for (int i = 0; i < h; i++)
    {

        int index2 = det(gen);
        int index = dis(gen);
        newState[index] = index2;
    }
   

    return newState;
}

// Main function
int main() {
    // Example file sizes (should be replaced with actual file sizes)
    std::vector<int> fileSizes = {
        173669, 275487, 1197613, 1549805, 502334, 217684, 1796841, 274708,
        631252, 148665, 150254, 4784408, 344759, 440109, 4198037, 329673,
        28602, 144173, 1461469, 187895, 369313, 959307, 1482335, 2772513,
        1313997, 254845, 486167, 2667146, 264004, 297223, 94694, 1757457,
        576203, 8577828, 498382, 8478177, 123575, 4062389, 3001419, 196884,
        617991, 421056, 3017627, 131936, 1152730, 2676649, 656678, 4519834,
        201919, 56080, 2142553, 326623, 8172117, 2304253, 4761871, 205387,
        6148422, 414559, 2893305, 2158562, 465972, 304078, 1841018, 1915571
    };



    

    // Run the simulated annealing 20 times
    std::vector<int> globalBestState;
    int bestOfBestEnergy=2*MEMORY_SIZE;

    for (int i = 0; i < 20; ++i) {
        energyFile.open(std::string("greske") + std::to_string(i) + ".txt");
        std::vector<int> state = simulatedAnnealing(fileSizes);
        int bestEnergy=calculateEnergy(state, fileSizes);
        if (bestEnergy < bestOfBestEnergy) {
            bestOfBestEnergy = bestEnergy;
            globalBestState = state;
        }
        energyFile.close();

    }

    // Close the energy file

    // Output the global best state
    for (int state : globalBestState) {
        std::cout << state << " ";
    }
    std::cout << "\nBest Energy: " << bestOfBestEnergy << std::endl;

    return 0;

}
